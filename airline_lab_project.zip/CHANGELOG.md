# CHANGELOG

## v0.3 - console UI
- Добавлен Main.java с простым консольным интерфейсом и демо-данными.

## v0.2 - services
- Добавлены FlightService и PassengerService:
  - Поиск рейсов по пункту назначения
  - Фильтрация пассажиров по минимальному возрасту

## v0.1 - models
- Добавлены классы-сущности Airplane, Flight, Passenger
